// show the title
showMessage("Title...");
let price = 149.99;
/*
    Detail complex logic...
    Some algorithm...

*/