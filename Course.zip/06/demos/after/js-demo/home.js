
let i = -4;
do {
    console.log(i);
    i--;
} while (i > 0);
